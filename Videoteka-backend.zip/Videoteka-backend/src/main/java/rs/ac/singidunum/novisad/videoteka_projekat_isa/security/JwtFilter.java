package rs.ac.singidunum.novisad.videoteka_projekat_isa.security;

import java.io.IOException;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import rs.ac.singidunum.novisad.videoteka_projekat_isa.utils.JwtUtil;

@Component
public class JwtFilter extends OncePerRequestFilter{

	private JwtUtil jwtUtil;
	private CustomUserDetailsService userDetailsService;
	
	public JwtFilter(JwtUtil jwtUtil, CustomUserDetailsService userDetailsService) {
		super();
		this.jwtUtil = jwtUtil;
		this.userDetailsService = userDetailsService;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String authHeader= request.getHeader("Authorization");
		
		if(authHeader==null || !authHeader.startsWith("Bearer ")) {
				filterChain.doFilter(request, response);
				return;
		}
		
		String token=authHeader.substring(7);
		
		if(!jwtUtil.isTokenValid(token)) {
			filterChain.doFilter(request, response);
			return;
		}
		
		String username=jwtUtil.extractUsername(token);
		
		if(username!= null && SecurityContextHolder.getContext().getAuthentication()==null) {
			UserDetails userDetails= userDetailsService.loadUserByUsername(username);
			
			UsernamePasswordAuthenticationToken authToken= 
					new UsernamePasswordAuthenticationToken( userDetails,null,userDetails.getAuthorities());
			
			authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
			
			SecurityContextHolder.getContext().setAuthentication(authToken);
		}
		
		filterChain.doFilter(request, response);
	}

}
